package oct.week1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date8 {

	public static void main(String[] args) throws InterruptedException, IOException {
	WebDriverManager.chromedriver().setup();
	ChromeOptions option=new ChromeOptions();
	option.addArguments("--disable.notifications");
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://www.makemytrip.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	WebElement frm=driver.findElementByXPath("//div[@id='webengage-notification-container']/iframe");
	driver.switchTo().frame(frm);
	Thread.sleep(10000);
	WebElement close=driver.findElementByXPath("//div[@class='container']/a");
	close.click();
	driver.switchTo().defaultContent();
	Thread.sleep(1000);
	driver.findElementByXPath("(//div[@class='chHeaderContainer']//li)[2]/a").click();
	driver.findElementByXPath("//label[@for='city']").click();
	WebElement city=driver.findElementByXPath("//div[@role='combobox']//input");
	city.sendKeys("Goa");
	Thread.sleep(2000);
	driver.findElementByXPath("(//div[@class='flexOne'])[1]").click();
	for(int i=0;i<=8;i++) {
	driver.findElementByXPath("(//div[@class='DayPicker-NavBar']/span)[2]").click();
	Thread.sleep(2000);
	String month=driver.findElementByXPath("(//div[@class='DayPicker-Caption']/div)[1]").getText();
	if(month.contains("May2021")) {
		for(int j=1;j<=42;j++) {
		String day=driver.findElementByXPath("(//div[@class='DayPicker-Day'])["+j+"]").getText();
		if(day.contains("15")) {
			driver.findElementByXPath("(//div[@class='DayPicker-Day'])[15]").click();
			Thread.sleep(2000);
		    driver.findElementByXPath("(//div[@class='DayPicker-Day'])[21]").click();
			Thread.sleep(2000);
				break;
			}
		}
		break;
		}
		}
	driver.findElementByXPath("//div[@class='hsw_inputBox roomGuests  ']").click();
	driver.findElementByXPath("(//div[@class='addRooomDetails']//li)[3]").click();
	driver.findElementByXPath("(//div[@class='addRooomDetails']//li)[15]").click();
	WebElement select1=driver.findElementByXPath("(//select[@class='ageSelectBox'])[1]");
	Select obj=new Select(select1);
	obj.selectByVisibleText("12");
	WebElement select2=driver.findElementByXPath("(//select[@class='ageSelectBox'])[2]");
	Select obj1=new Select(select2);
	obj1.selectByVisibleText("12");
	Thread.sleep(2000);
	driver.findElementByXPath("//button[@class='primaryBtn btnApply']").click();
	driver.findElementByXPath("//button[@id='hsw_search_button']").click();
	Thread.sleep(3000);
	driver.findElementByXPath("//label[@for='Preferred By Tourists_3']/span").click();
	Thread.sleep(4000);
	driver.findElementByXPath("(//span[@class='checkmarkOuter']/label)[14]").click();
	driver.findElementByXPath("(//div[@id='Listing_hotel_0']//div)[1]").click();
	Set<String> allwindow= driver.getWindowHandles();
	List<String> win=new ArrayList<String>();
	win.addAll(allwindow);
	String parent=win.get(0);
	String child=win.get(1);
	driver.switchTo().window(child);
	Thread.sleep(2000);
	String hotelname=driver.findElementByXPath("//div[@class='flexOne']//h1").getText();
	System.out.println("The hotel name="+" "+hotelname);
	driver.findElementByXPath("//a[@rel='nofollow']/span").click();
	String totalamount=driver.findElementByXPath("//span[@id='revpg_total_payable_amt']").getText();
	System.out.println("The total payable Amount is="+" "+totalamount);
	File src=driver.getScreenshotAs(OutputType.FILE);
	File dest=new File("./snaps/output.png");
	FileUtils.copyFile(src, dest);
	Thread.sleep(2000);
	driver.close();
	driver.switchTo().window(parent);
	Thread.sleep(2000);
	driver.close();
	    }
	}
