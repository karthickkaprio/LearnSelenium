package oct.week1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Date6 {
	public static void main(String[] args) throws InterruptedException, IOException {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.snapdeal.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.findElementByXPath("(//div[@id='leftNavMenuRevamp']//li)[9]").click();
		driver.findElementByXPath("//span[text()='Toys']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("(//li[@class='sub-cat-list cat-list '])[2]").click();
		WebElement rating=driver.findElementByXPath("//label[@for='avgRating-4.0']");
		Actions builder=new Actions(driver);
		builder.click(rating).perform();
		Thread.sleep(2000);
		driver.findElementByXPath("(//div[@data-name='discount']//label)[5]").click();
		driver.findElementByXPath("//input[@placeholder='Enter your pincode']").sendKeys("600028");
		driver.findElementByXPath("//button[@class='pincode-check']").click();
		Thread.sleep(2000);
	    //String parent=driver.getWindowHandle();
	    //System.out.println(parent);
		WebElement quikview=driver.findElementByXPath("//a[@class='dp-widget-link hashAdded']");
		Actions builder1= new Actions(driver);
		builder1.click(quikview).perform();
		Thread.sleep(3000);
		Set<String> allwindow=driver.getWindowHandles();
		List<String> window=new ArrayList<String>();
		window.addAll(allwindow);
		String parentwindow=window.get(0);
		String childwindow=window.get(1);
		System.out.println(childwindow);
		driver.switchTo().window(childwindow);
		//driver.findElementByLinkText("view details").click();
		String product1=driver.findElementByXPath("//span[@class='payBlkBig']").getText();
		int num1=Integer.parseInt(product1);
		System.out.println("cost of first product="+" "+num1);
		driver.findElementByXPath("//div[@id='add-cart-button-id']/span").click();
		Thread.sleep(2000);
		driver.close();
		driver.switchTo().window(parentwindow);
		driver.findElementByXPath("//input[@id='inputValEnter']").sendKeys("sanitizer",Keys.ENTER);
		driver.findElementByXPath("//img[@title='Vedic Valley Hand Sanitizer 5000 mL Pack of 1']").click();
		Set<String>sanitiser=driver.getWindowHandles();
		List<String> sanwin=new ArrayList<String>();
		sanwin.addAll(sanitiser);
		String parent=sanwin.get(0);
		String child=sanwin.get(1);
		Thread.sleep(3000);
	    driver.switchTo().window(child);
		String product2=driver.findElementByXPath("//span[@class='payBlkBig']").getText();
		int num2=Integer.parseInt(product2);
		System.out.println("cost of second product="+" "+num2);
		driver.findElementByXPath("(//div[@id='add-cart-button-id']/span)[1]").click();
		Thread.sleep(2000);
		driver.close();
		driver.switchTo().window(parent);
		int total=num1+num2;
		System.out.println("the sum of two product="+" "+total);
		String total1=Integer.toString(total);
		System.out.println("total1="+" "+total1);
		
		driver.findElementByXPath("//div[@class='cartInner']").click();
		Thread.sleep(2000);
		File src=driver.getScreenshotAs(OutputType.FILE);
		File dest=new File("./snaps/output.png");
		FileUtils.copyFile(src, dest);
	    String totalamount=driver.findElementByXPath("(//div[@class='cart-bill-wrapper rfloat']//input)[3]").getAttribute("value");
		String totalamount1=totalamount.replaceAll("\\D","");
		System.out.println("totalamount="+" "+totalamount1);
		if(totalamount1.equals(total1)) {
			System.out.println("the total amount matches");
		}
		else {
			System.out.println("check the total amount not matching");
		}
		 driver.close();
		}
	}
